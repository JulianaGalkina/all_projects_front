const express = require('express');
const app = express();

let users = [
    {'id': 1, 'name': 'Elvin'},
    {'id': 2, 'name': 'Ivan'},
    {'id': 3, 'name': 'Yura'},
    {'id': 4, 'name': 'Dasha'},
    {'id': 5, 'name': 'Juliana'}
  ];
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
  
app.get('/users', (req, res)=>{
    res.status(200).json(users);
});

app.post('/userwhy', (req, res) => {
    users.push(req.body);
    res.send(req.body);
    console.log(req.body)
})

app.get('/username/:id', (req, res) => {
    const userID = parseInt(req.params.id);
    const user = user.find((user)=> user.id ===userID).name;
    if(!user){
        res.send(404).send();
    }
    res.status(200).json(user);
});

app.get('/user', (req, res) => {
    const count = parseInt(req.query.count);
    const offset = parseInt(req.query.offset);
    res.send({users: users.slice(offset, offset+count)});
    console.log(req);
})

app.put("/user/:id", (req, res)=>{
    const userID = parseInt(req.params.id);
    const userWithId = users.findIndex((user) => user.id === userID);
  
    if (userWithId !== -1){
      const oldUser = users[userWithId];
      users[userWithId] = {...oldUser, ...req.body};
      res.json(users[userWithId]);
    } else {
      res.status(404).json();
    }
});

app.delete('/user/:id', (req, res)=>{
    users = users.filter((user) => user.id !== parseInt(req.params.id));
    res.json(users);
  })
  

app.listen(3000, 'localhost', () =>{
    console.log('Exaple app listenning on port 3000!');
});