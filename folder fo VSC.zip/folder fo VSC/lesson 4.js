let id = prompt('Введите ID товара');
switch(id) {
    case '1':
        alert('Доступно 10шт.');
        break;
    case '2':
        alert('Доступно 256шт.');
        break;
    case '3':
        alert('Доступно 53шт.');
        break;
    case '4':
        alert('Доступно 5шт.');
        break;
    default:
        alert('Товар недоступен.')
}



let gender = prompt('What is your gender? m or f?');
let answer = gender == 'm' ?
'male':'famale';
console.log(gender)
console.log(answer)

function logGreeting() {
    console.log(`${name} is a JS developed`)
}
let name = 'Juliana';
logGreeting()

function enter(name) {
    console.log(`${name} is active now`)
}
enter('Juliana')
enter('Yana')
enter('Vlad')