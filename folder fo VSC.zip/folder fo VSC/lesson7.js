const name = ['Juliana', 'Juli', 'Jugg'];

name[1] = 'Classified'
console.log(name)

const arr = ['New Hope', 'Empire strikes back', 'Return of the Jdi'];
for (let i = 0; i< arr.length; i+=1){
}

const characters = ['Peter', 'Gwen', 'Norman'];
characters.push('Juliana');
characters.shift();
console.log(characters)

const salary = [20000, 20000, 20000, 20000, 20000, 20000, 20000, 20000, 20000, 20000 ];
let i=0; 
let sum = 0;
while (i<= salary.length){
    sum+=Number(salary[i]);
}
console.log(sum)