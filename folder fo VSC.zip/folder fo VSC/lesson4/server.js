const express = require('express');
const app = express();

const cards = [
    {'id': 1, 'number': '34567890'},
    {'id': 2, 'number': '3743965'},
    {'id': 3, 'number': '12094'},
    {'id': 4, 'number': '23470891'},
    {'id': 5, 'number': '2736470'}
  ];

app.get('/card/:id', (req, res) => {
    const cardID = parseInt(req.params.id);
    const card = cards.find((card)=> card.id ===cardID).number;
    if(!user){
        res.send(404).send();
    }
    res.status(200).json(card);
});

app.listen(3000, () =>{
    console.log('Exaple app listenning on port 3000!');
})