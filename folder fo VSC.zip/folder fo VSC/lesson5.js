function min(a, b) {
    if (a>b){
        return b;
    }
    if (b>a) {
        return a;
    }
    else {
        return 'Eror'
    }
}
let value = min(5,5);
console.log(value)

const min = (a, b) => {
    if (a>b){
        return b;
    }
    if (b>a) {
        return a;
    }
    else {
        return 'Eror'
    }
}
value = min(7,5);
console.log(value)

let st = prompt('Введите начальное число: ');
let end = prompt('Введите конечное число: ');
let sum=0;
for (let i = Number(st); i <= Number(end); i++ ){
    sum += i
}
console.log(sum)

let txt = 'Hello. Word';
for( i=0; i < txt.length; i++){
    if (txt[i] === '.'){
        console.log(i)
        break;
    }
}
