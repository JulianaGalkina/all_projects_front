let firstName = "Juliana";
let lastName = "Galkina";
console.log(`Dear ${firstName} ${lastName}, welcome!`);


let fullName = `${firstName} ${lastName}`;
let prob = fullName.indexOf(' ');
console.log(22/0)
