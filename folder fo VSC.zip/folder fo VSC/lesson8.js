const txt = '32, 31, 34, 36, 31';
const text = txt.split(',');
console.log(text.join(';'))