const fs = require('fs');

const readStr = fs.createReadStream('./docs/doc1.txt');

readStr.on ('data', (chunk) => {
    console.log('---New Chunk');
    console.log (chunk);
})