const students = ['Ivan', 'Juliana'];
const age = [16, 16];
console.log(students);

module.exports = {students, age};