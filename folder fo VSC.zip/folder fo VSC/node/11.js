console.log('hello');

const people = require('./new1');
console.log(people.students, people.age)