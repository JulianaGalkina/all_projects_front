const bookPrise = 300;
const bookAmount = 900;
console.log(bookPrise * bookAmount)